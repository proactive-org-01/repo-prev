resource "aws_s3_bucket" "costpredict" {
  bucket = "costpredict-bucket"
  tags = {
    Environment = "dev"
  }
}