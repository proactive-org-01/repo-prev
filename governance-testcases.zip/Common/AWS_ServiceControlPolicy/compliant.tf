resource "aws_instance" "allowed" {
  ami           = "ami-12345678"
  instance_type = "t3.micro"
}