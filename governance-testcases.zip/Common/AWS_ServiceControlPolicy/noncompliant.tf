resource "aws_redshift_cluster" "restricted" {
  cluster_identifier = "restricted-cluster"
  node_type          = "dc2.large"
  master_username    = "admin"
  master_password    = "Password123!"
}