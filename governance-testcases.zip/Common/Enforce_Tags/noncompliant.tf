resource "aws_s3_bucket" "untagged" {
  bucket = "my-untagged-bucket"
  tags = {
    Environment = "dev"
  }
}