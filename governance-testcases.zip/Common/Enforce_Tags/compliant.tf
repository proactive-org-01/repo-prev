resource "aws_s3_bucket" "tagged" {
  bucket = "my-tagged-bucket"
  tags = {
    Environment = "dev"
    Owner       = "sneha"
    Reason      = "app-testing"
  }
}