resource "azurerm_cognitive_deployment" "openai_basic" {
  name                 = "openai-basic"
  cognitive_account_id = "example-account-id"

  model {
    format  = "OpenAI"
    name    = "gpt-3.5-turbo"
    version = "1"
  }

  sku {
    name     = "S0"
    capacity = 5
  }
}